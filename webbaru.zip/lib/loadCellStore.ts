"use client"

// Load cell store yang mendukung pengiriman data per 20 gram dari Firebase
class LoadCellStore {
  private static instance: LoadCellStore
  private currentWeightGrams = 0 // Berat yang diterima dari Firebase (per 20g)
  private dailyWeightsGrams: number[] = []
  private totalEarnings = 0
  private completedCycles = 0
  private isRunning = false
  private interval: NodeJS.Timeout | null = null
  private listeners: Set<() => void> = new Set()
  private lastUpdate = 0
  private readonly MAX_DAILY_WEIGHTS = 50
  private readonly UPDATE_INTERVAL = 3000 // 3 detik untuk dummy
  private readonly MIN_INCREMENT_GRAMS = 20 // Minimum 20 gram
  private readonly MAX_INCREMENT_GRAMS = 60 // Maksimum 60 gram (kelipatan 20)

  // Harga per kg
  private readonly PRICE_BEFORE_SORTING_PER_KG = 8000 // Rp 8.000 per kg sebelum pilah
  private readonly PRICE_AFTER_SORTING_PER_KG = 13000 // Rp 13.000 per kg setelah pilah

  // Integrasi Firebase
  private useFirebase = false
  private firebaseConnected = false
  private firebaseUnsubscribeConnection: (() => void) | null = null
  private firebaseUnsubscribeData: (() => void) | null = null

  static getInstance(): LoadCellStore {
    if (!LoadCellStore.instance) {
      LoadCellStore.instance = new LoadCellStore()
    }
    return LoadCellStore.instance
  }

  subscribe(listener: () => void) {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  private notify() {
    const now = Date.now()
    if (now - this.lastUpdate < 100) return

    this.lastUpdate = now
    this.listeners.forEach((listener) => {
      try {
        listener()
      } catch (error) {
        console.warn("Listener error:", error)
      }
    })
  }

  async connectToFirebase(): Promise<boolean> {
    try {
      const { firebaseService } = await import("./firebase")

      this.firebaseUnsubscribeConnection = firebaseService.subscribeConnection((connected) => {
        this.firebaseConnected = connected
        if (!connected && this.useFirebase) {
          console.warn("Firebase terputus, kembali ke data dummy")
          this.useFirebase = false
          this.startDummySimulation()
        }
        this.notify()
      })

      this.firebaseUnsubscribeData = firebaseService.subscribeData((gram) => {
        if (gram > 0 && this.useFirebase) {
          this.handleFirebaseGram(gram)
        }
      })

      const connected = await firebaseService.connect()

      if (connected) {
        this.useFirebase = true
        this.stopDummySimulation()
        console.log("Terhubung ke Firebase - mengambil data dari berat/LC1")
        return true
      } else {
        console.warn("Gagal terhubung ke Firebase, menggunakan data dummy")
        this.useFirebase = false
        this.startDummySimulation()
        return false
      }
    } catch (error) {
      console.error("Firebase connection error:", error)
      this.useFirebase = false
      this.startDummySimulation()
      return false
    }
  }

  disconnectFromFirebase() {
    this.useFirebase = false
    const { firebaseService } = require("./firebase")
    firebaseService.disconnect()

    if (this.firebaseUnsubscribeConnection) {
      this.firebaseUnsubscribeConnection()
      this.firebaseUnsubscribeConnection = null
    }

    if (this.firebaseUnsubscribeData) {
      this.firebaseUnsubscribeData()
      this.firebaseUnsubscribeData = null
    }

    this.firebaseConnected = false
    this.startDummySimulation()
    this.notify()
  }

  private handleFirebaseGram(gram: number) {
    console.log(`Load Cell Store menerima: ${gram}g`)

    // Update berat saat ini
    this.currentWeightGrams = gram

    // Tambah ke daily weights untuk perhitungan rata-rata
    this.dailyWeightsGrams.push(gram)
    if (this.dailyWeightsGrams.length > this.MAX_DAILY_WEIGHTS) {
      this.dailyWeightsGrams = this.dailyWeightsGrams.slice(-this.MAX_DAILY_WEIGHTS)
    }

    // Hitung keuntungan berdasarkan harga baru (Rp 13.000 per kg)
    const weightKg = this.currentWeightGrams / 1000
    this.totalEarnings = Math.floor(weightKg * this.PRICE_AFTER_SORTING_PER_KG)

    // Update completed cycles untuk tracking (setiap 1 kg)
    this.completedCycles = Math.floor(weightKg)

    this.notify()
  }

  startDummySimulation() {
    if (this.isRunning || this.useFirebase) return

    this.isRunning = true
    this.interval = setInterval(() => {
      // Penambahan data dummy dalam kelipatan 20 gram
      const possibleIncrements = [20, 40, 60] // Kelipatan 20
      const increment = possibleIncrements[Math.floor(Math.random() * possibleIncrements.length)]

      this.currentWeightGrams += increment
      console.log(`Dummy data: menambah ${increment}g, total: ${this.currentWeightGrams}g`)

      // Tambah ke daily weights
      this.dailyWeightsGrams.push(this.currentWeightGrams)
      if (this.dailyWeightsGrams.length > this.MAX_DAILY_WEIGHTS) {
        this.dailyWeightsGrams = this.dailyWeightsGrams.slice(-this.MAX_DAILY_WEIGHTS)
      }

      // Hitung keuntungan berdasarkan harga baru (Rp 13.000 per kg)
      const weightKg = this.currentWeightGrams / 1000
      this.totalEarnings = Math.floor(weightKg * this.PRICE_AFTER_SORTING_PER_KG)

      // Update completed cycles untuk tracking (setiap 1 kg)
      this.completedCycles = Math.floor(weightKg)

      this.notify()
    }, this.UPDATE_INTERVAL)
  }

  private stopDummySimulation() {
    if (this.interval) {
      clearInterval(this.interval)
      this.interval = null
    }
    this.isRunning = false
  }

  startSimulation() {
    if (this.useFirebase) {
      // Firebase menangani update real-time
      return
    } else {
      this.startDummySimulation()
    }
  }

  stopSimulation() {
    this.stopDummySimulation()
  }

  getCurrentWeight(): number {
    return this.currentWeightGrams / 1000 // Konversi ke kg untuk ditampilkan
  }

  getCurrentWeightGrams(): number {
    return this.currentWeightGrams
  }

  getDailyAverage(): number {
    if (this.dailyWeightsGrams.length === 0) return 0
    const sum = this.dailyWeightsGrams.reduce((acc, weight) => acc + weight, 0)
    return sum / this.dailyWeightsGrams.length / 1000 // Konversi ke kg untuk ditampilkan
  }

  getTotalEarnings(): number {
    return this.totalEarnings
  }

  // Hitung keuntungan sebelum pilah
  getTotalEarningsBeforeSorting(): number {
    const weightKg = this.currentWeightGrams / 1000
    return Math.floor(weightKg * this.PRICE_BEFORE_SORTING_PER_KG)
  }

  getCompletedCycles(): number {
    return this.completedCycles
  }

  getRealtimeDataInGrams(): number[] {
    // Buat data chart dalam gram untuk ditampilkan (0-1000g)
    const baseWeight = Math.max(0, this.currentWeightGrams - 100)
    return Array.from({ length: 5 }, (_, i) => {
      const weight = baseWeight + i * 20 + Math.random() * 10
      return Math.min(1000, Math.max(0, Math.round(weight))) // Pastikan dalam range 0-1000g
    })
  }

  getRealtimeData(): number[] {
    // Buat data chart dalam kg untuk ditampilkan (untuk chart lain)
    const baseWeightKg = Math.max(0, (this.currentWeightGrams - 1000) / 1000)
    return Array.from({ length: 5 }, (_, i) => {
      const weight = baseWeightKg + i * 0.02 + Math.random() * 0.01
      return Math.round(weight * 1000) / 1000
    })
  }

  // Getter untuk harga
  getPriceBeforeSorting(): number {
    return this.PRICE_BEFORE_SORTING_PER_KG
  }

  getPriceAfterSorting(): number {
    return this.PRICE_AFTER_SORTING_PER_KG
  }

  isUsingFirebase(): boolean {
    return this.useFirebase
  }

  isFirebaseConnected(): boolean {
    return this.firebaseConnected
  }

  // Method untuk mendapatkan debug info dari Firebase
  getFirebaseDebugInfo() {
    if (this.useFirebase) {
      const { firebaseService } = require("./firebase")
      return firebaseService.getDebugInfo()
    }
    return null
  }

  reset() {
    this.currentWeightGrams = 0
    this.dailyWeightsGrams = []
    this.totalEarnings = 0
    this.completedCycles = 0

    // Reset Firebase tracking juga
    if (this.useFirebase) {
      const { firebaseService } = require("./firebase")
      firebaseService.disconnect()
      setTimeout(() => {
        this.connectToFirebase()
      }, 1000)
    }

    this.notify()
  }

  cleanup() {
    this.stopSimulation()
    this.disconnectFromFirebase()
    this.listeners.clear()
    this.dailyWeightsGrams = []
  }
}

export const loadCellStore = LoadCellStore.getInstance()

// Cleanup saat halaman dimuat ulang
if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", () => {
    loadCellStore.cleanup()
  })
}
