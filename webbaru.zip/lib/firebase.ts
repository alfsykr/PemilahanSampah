"use client"

/**
 * Firebase service yang mengambil data dari berat/LC1 dan mengirim per 20 gram
 */

import type { FirebaseApp } from "firebase/app"
import { initializeApp, type FirebaseOptions } from "firebase/app"
import { getDatabase, ref, onValue, off, type DatabaseReference } from "firebase/database"

let FirebaseServiceImpl: any

if (typeof window !== "undefined") {
  // -----  Browser  ----------------------------------------------------
  const firebaseConfig: FirebaseOptions = {
    apiKey: "AIzaSyA2eBJjl9PXZw9jRZCrhbKvYmyTdLD7Sbw",
    authDomain: "tugasakhir2025khairil.firebaseapp.com",
    databaseURL: "https://tugasakhir2025khairil-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "tugasakhir2025khairil",
    storageBucket: "tugasakhir2025khairil.appspot.com",
    messagingSenderId: "163871892502",
    appId: "1:163871892502:web:487433946188036b490137",
  }

  const app: FirebaseApp = initializeApp(firebaseConfig)
  const database = getDatabase(app)

  class FirebaseService {
    private dbRef: DatabaseReference | null = null
    private connected = false
    private connListeners = new Set<(c: boolean) => void>()
    private dataListeners = new Set<(g: number) => void>()

    // Tracking untuk pengiriman per 20 gram
    private lastSentWeight = 0
    private currentRawWeight = 0
    private sendInterval: NodeJS.Timeout | null = null

    subscribeConnection(fn: (c: boolean) => void) {
      this.connListeners.add(fn)
      fn(this.connected)
      return () => this.connListeners.delete(fn)
    }

    subscribeData(fn: (g: number) => void) {
      this.dataListeners.add(fn)
      return () => this.dataListeners.delete(fn)
    }

    private emitConn(c: boolean) {
      this.connected = c
      this.connListeners.forEach((f) => f(c))
    }

    private emitData(g: number) {
      this.dataListeners.forEach((f) => f(g))
    }

    private processWeightData(rawWeight: number) {
      this.currentRawWeight = rawWeight

      // Hitung berapa kelipatan 20 yang bisa dikirim
      const targetWeight = Math.floor(rawWeight / 20) * 20

      // Jika target weight lebih besar dari yang sudah dikirim, kirim bertahap
      if (targetWeight > this.lastSentWeight) {
        this.startGradualSending(targetWeight)
      }
    }

    private startGradualSending(targetWeight: number) {
      // Clear interval sebelumnya jika ada
      if (this.sendInterval) {
        clearInterval(this.sendInterval)
      }

      // Kirim data bertahap per 20 gram setiap 2 detik
      this.sendInterval = setInterval(() => {
        if (this.lastSentWeight < targetWeight) {
          this.lastSentWeight += 20
          console.log(`Mengirim data: ${this.lastSentWeight}g (dari total ${this.currentRawWeight}g)`)
          this.emitData(this.lastSentWeight)
        } else {
          // Sudah mencapai target, hentikan interval
          if (this.sendInterval) {
            clearInterval(this.sendInterval)
            this.sendInterval = null
          }
        }
      }, 2000) // Kirim setiap 2 detik
    }

    async connect(): Promise<boolean> {
      if (this.dbRef) return this.connected

      // Ubah path ke berat/LC1
      this.dbRef = ref(database, "berat/LC1")

      return new Promise((resolve) => {
        const to = setTimeout(() => {
          this.emitConn(false)
          resolve(false)
        }, 10_000)

        onValue(
          this.dbRef!,
          (snap) => {
            clearTimeout(to)
            if (!snap.exists()) {
              this.emitConn(false)
              resolve(false)
              return
            }

            const rawWeight = Number(snap.val()) || 0
            console.log(`Data Firebase diterima: ${rawWeight}g`)

            this.emitConn(true)
            this.processWeightData(rawWeight)

            if (!this.connected) {
              resolve(true)
            }
          },
          (error) => {
            clearTimeout(to)
            console.error("Firebase error:", error)
            this.emitConn(false)
            resolve(false)
          },
        )
      })
    }

    disconnect() {
      if (this.dbRef) off(this.dbRef)
      if (this.sendInterval) {
        clearInterval(this.sendInterval)
        this.sendInterval = null
      }
      this.dbRef = null
      this.lastSentWeight = 0
      this.currentRawWeight = 0
      this.emitConn(false)
    }

    // Method untuk mendapatkan info debug
    getDebugInfo() {
      return {
        rawWeight: this.currentRawWeight,
        sentWeight: this.lastSentWeight,
        nextTarget: Math.floor(this.currentRawWeight / 20) * 20,
        isProcessing: this.sendInterval !== null,
      }
    }
  }

  FirebaseServiceImpl = new FirebaseService()
} else {
  // -----  Server / SSR  ------------------------------------------------
  class FirebaseStub {
    subscribeConnection(fn: (c: boolean) => void) {
      fn(false)
      return () => {}
    }
    subscribeData(fn: (g: number) => void) {
      fn(0)
      return () => {}
    }
    async connect() {
      return false
    }
    disconnect() {}
    getDebugInfo() {
      return { rawWeight: 0, sentWeight: 0, nextTarget: 0, isProcessing: false }
    }
  }

  FirebaseServiceImpl = new FirebaseStub()
}

export const firebaseService = FirebaseServiceImpl
