"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import { Line } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"
import { loadCellStore } from "@/lib/loadCellStore"
import FirebaseToggle from "@/components/FirebaseToggle"

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend)

export default function DataLoadCell() {
  const [isLoaded, setIsLoaded] = useState(false)
  const [currentWeight, setCurrentWeight] = useState(0)
  const [currentWeightGrams, setCurrentWeightGrams] = useState(0)
  const [dailyAverage, setDailyAverage] = useState(0)
  const [totalEarnings, setTotalEarnings] = useState(0)
  const [completedCycles, setCompletedCycles] = useState(0)
  const [realtimeData, setRealtimeData] = useState<number[]>([])
  const [useFirebase, setUseFirebase] = useState(false)
  const [priceAfterSorting, setPriceAfterSorting] = useState(0)

  // Optimized update handler
  const updateData = useCallback(() => {
    setCurrentWeight(loadCellStore.getCurrentWeight())
    setCurrentWeightGrams(loadCellStore.getCurrentWeightGrams())
    setDailyAverage(loadCellStore.getDailyAverage())
    setTotalEarnings(loadCellStore.getTotalEarnings())
    setCompletedCycles(loadCellStore.getCompletedCycles())
    setRealtimeData(loadCellStore.getRealtimeDataInGrams()) // Fungsi baru untuk gram
    setUseFirebase(loadCellStore.isUsingFirebase())
    setPriceAfterSorting(loadCellStore.getPriceAfterSorting())
  }, [])

  useEffect(() => {
    setIsLoaded(true)

    const unsubscribe = loadCellStore.subscribe(updateData)
    loadCellStore.startSimulation()
    updateData()

    return unsubscribe
  }, [updateData])

  // Memoized calculations
  const calculations = useMemo(() => {
    const remainingWeight = currentWeight - completedCycles

    return {
      remainingWeight,
      progressPercentage: (currentWeight % 1) * 100, // Progress per kg
    }
  }, [currentWeight, completedCycles])

  // Memoized chart data - ubah untuk menampilkan dalam gram
  const chartData = useMemo(
    () => ({
      labels: ["20s ago", "15s ago", "10s ago", "5s ago", "Now"],
      datasets: [
        {
          label: "Berat Real-time (gram)",
          data: realtimeData, // Sekarang dalam gram
          borderColor: useFirebase ? "#3b82f6" : "#059669",
          backgroundColor: useFirebase ? "rgba(59, 130, 246, 0.1)" : "rgba(5, 150, 105, 0.1)",
          tension: 0.4,
          fill: true,
        },
      ],
    }),
    [realtimeData, useFirebase],
  )

  // Memoized chart options - ubah untuk gram dan range 0-1000
  const chartOptions = useMemo(
    () => ({
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: "top" as const,
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          min: 0,
          max: 1000, // Maksimum 1000 gram
          ticks: {
            callback: (value: any) => value + " g",
            stepSize: 100, // Step 100 gram
          },
        },
      },
      animation: {
        duration: 300,
      },
    }),
    [],
  )

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="loading-spinner"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-emerald-700 mb-6">Data Load Cell</h1>
      </div>

      {/* Firebase Toggle */}
      <FirebaseToggle />

      {/* Current Weight Display - Enhanced with grams */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Berat Saat Ini</h2>
          <div className="text-6xl font-bold text-emerald-600 mb-2 animate-pulse">{currentWeight.toFixed(1)} kg</div>
          <div className="text-lg text-gray-600 mb-4">({currentWeightGrams.toLocaleString()} gram)</div>
          <div className="flex justify-center items-center space-x-2 mb-4">
            <div
              className={`w-3 h-3 rounded-full animate-ping ${useFirebase ? "bg-blue-500" : "bg-emerald-500"}`}
            ></div>
            <span className={`font-medium ${useFirebase ? "text-blue-600" : "text-emerald-600"}`}>
              {useFirebase ? "Firebase Live" : "Simulasi"}
            </span>
          </div>

          {/* Progress info */}
          <div className="max-w-md mx-auto">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Keuntungan per kg:</span>
              <span className="font-semibold text-emerald-600">Rp {priceAfterSorting.toLocaleString("id-ID")}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`h-3 rounded-full transition-all duration-500 ${useFirebase ? "bg-blue-600" : "bg-emerald-600"}`}
                style={{ width: `${calculations.progressPercentage}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Earnings Display - Enhanced */}
      <div
        className={`bg-gradient-to-br text-white rounded-xl p-6 animate-slide-up ${
          useFirebase ? "from-blue-500 to-blue-600" : "from-emerald-500 to-emerald-600"
        }`}
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-3xl mb-2">💰</div>
            <div className="text-2xl font-bold">Rp {totalEarnings.toLocaleString("id-ID")}</div>
            <div className={useFirebase ? "text-blue-100" : "text-emerald-100"}>Total Keuntungan</div>
            <div className="text-xs mt-1 opacity-80">Rp {priceAfterSorting.toLocaleString("id-ID")}/kg</div>
          </div>
          <div>
            <div className="text-3xl mb-2">📊</div>
            <div className="text-2xl font-bold">{completedCycles.toFixed(1)} kg</div>
            <div className={useFirebase ? "text-blue-100" : "text-emerald-100"}>Berat Terhitung</div>
          </div>
          <div>
            <div className="text-3xl mb-2">⚖️</div>
            <div className="text-2xl font-bold">{calculations.remainingWeight.toFixed(1)} kg</div>
            <div className={useFirebase ? "text-blue-100" : "text-emerald-100"}>Sisa Berat</div>
          </div>
        </div>
      </div>

      {/* Real-time Chart - Enhanced */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <span className="text-2xl mr-2">⚖️</span>
          Monitoring Real-time Load Cell
          <span
            className={`ml-2 px-2 py-1 text-xs rounded-full ${
              useFirebase ? "bg-blue-100 text-blue-700" : "bg-emerald-100 text-emerald-700"
            }`}
          >
            {useFirebase ? "Firebase" : "Simulasi"}
          </span>
        </h3>
        <div className="h-96">
          <Line data={chartData} options={chartOptions} />
        </div>
      </div>

      {/* Statistics Cards - Enhanced */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl p-6 animate-slide-up">
          <div className="text-3xl mb-2">📊</div>
          <div className="text-2xl font-bold">{dailyAverage.toFixed(1)} kg</div>
          <div className="text-blue-100">Rata-rata Harian</div>
          <div className="text-xs text-blue-200 mt-1">
            {dailyAverage > 0 ? "Berdasarkan data terkumpul" : "Belum ada data"}
          </div>
        </div>
        <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-xl p-6 animate-slide-up">
          <div className="text-3xl mb-2">💵</div>
          <div className="text-2xl font-bold">Rp {priceAfterSorting.toLocaleString("id-ID")}</div>
          <div className="text-orange-100">Harga per Kg</div>
          <div className="text-xs text-orange-200 mt-1">Setelah pilah</div>
        </div>
      </div>

      {/* Calculation Details - Enhanced with new prices */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <span className="text-2xl mr-2">🧮</span>
          Detail Perhitungan
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Sistem Perhitungan:</span>
              <span className="font-semibold">Per Kg</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
              <span className="text-gray-600">Harga Sebelum Pilah:</span>
              <span className="font-semibold text-red-600">Rp 8.000/kg</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-lg">
              <span className="text-gray-600">Harga Setelah Pilah:</span>
              <span className="font-semibold text-emerald-600">Rp 13.000/kg</span>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-lg">
              <span className="text-gray-600">Berat Terkumpul:</span>
              <span className="font-semibold">
                {currentWeight.toFixed(1)} kg ({currentWeightGrams.toLocaleString()}g)
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-lg">
              <span className="text-gray-600">Selisih Keuntungan:</span>
              <span className="font-semibold text-emerald-600">+Rp 5.000/kg</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-lg">
              <span className="text-gray-600">Total Keuntungan:</span>
              <span className="font-semibold text-emerald-600">Rp {totalEarnings.toLocaleString("id-ID")}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Control Buttons - Enhanced */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Kontrol Sistem</h3>
        <div className="flex gap-4 flex-wrap">
          <button
            onClick={() => loadCellStore.reset()}
            className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors duration-200"
          >
            Reset Data
          </button>
          <div className="flex items-center text-sm text-gray-600">
            <div
              className={`w-2 h-2 rounded-full animate-pulse mr-2 ${useFirebase ? "bg-blue-500" : "bg-green-500"}`}
            ></div>
            {useFirebase ? "Data real-time dari Firebase" : "Simulasi berjalan otomatis"}
          </div>
        </div>
      </div>
    </div>
  )
}
