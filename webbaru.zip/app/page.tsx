"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import { Line, Bar } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"
import { loadCellStore } from "@/lib/loadCellStore"

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend)

// Memoized chart options to prevent recreation
const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: "top" as const,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
    },
  },
  animation: {
    duration: 300, // Reduced animation duration
  },
}

export default function Dashboard() {
  const [isLoaded, setIsLoaded] = useState(false)
  const [currentWeight, setCurrentWeight] = useState(0)
  const [dailyAverage, setDailyAverage] = useState(0)
  const [totalEarnings, setTotalEarnings] = useState(0)
  const [totalEarningsBeforeSorting, setTotalEarningsBeforeSorting] = useState(0)
  const [completedCycles, setCompletedCycles] = useState(0)
  const [priceBeforeSorting, setPriceBeforeSorting] = useState(0)
  const [priceAfterSorting, setPriceAfterSorting] = useState(0)

  // Static data - memoized to prevent recreation
  const monthlyData = useMemo(
    () => ({
      weights: [100, 150, 200, 180, 220],
      profitBefore: [800000, 1200000, 1600000, 1440000, 1760000], // Rp 8.000 per kg
    }),
    [],
  )

  // Memoized chart data
  const chartData = useMemo(() => {
    const monthlyProfitAfter = monthlyData.weights.map((weight) => weight * 13000) // Rp 13.000 per kg

    return {
      weight: {
        labels: ["Jan", "Feb", "Mar", "Apr", "Mei"],
        datasets: [
          {
            label: "Berat Sampah (kg)",
            data: monthlyData.weights,
            borderColor: "#059669",
            backgroundColor: "rgba(5, 150, 105, 0.1)",
            tension: 0.3,
            fill: true,
          },
        ],
      },
      profit: {
        labels: ["Jan", "Feb", "Mar", "Apr", "Mei"],
        datasets: [
          {
            label: "Sebelum Pilah (Rp 8.000/kg)",
            data: monthlyData.profitBefore,
            backgroundColor: "#ef4444",
          },
          {
            label: "Sesudah Pilah (Rp 13.000/kg)",
            data: monthlyProfitAfter,
            backgroundColor: "#059669",
          },
        ],
      },
    }
  }, [monthlyData])

  // Optimized update handler
  const updateData = useCallback(() => {
    setCurrentWeight(loadCellStore.getCurrentWeight())
    setDailyAverage(loadCellStore.getDailyAverage())
    setTotalEarnings(loadCellStore.getTotalEarnings())
    setTotalEarningsBeforeSorting(loadCellStore.getTotalEarningsBeforeSorting())
    setCompletedCycles(loadCellStore.getCompletedCycles())
    setPriceBeforeSorting(loadCellStore.getPriceBeforeSorting())
    setPriceAfterSorting(loadCellStore.getPriceAfterSorting())
  }, [])

  useEffect(() => {
    setIsLoaded(true)

    // Subscribe to load cell store updates
    const unsubscribe = loadCellStore.subscribe(updateData)

    // Start simulation if not already running
    loadCellStore.startSimulation()

    // Initial data load
    updateData()

    return unsubscribe
  }, [updateData])

  // Memoized calculations
  const calculations = useMemo(() => {
    const profitIncrease =
      totalEarnings > 0 && totalEarningsBeforeSorting > 0
        ? (((totalEarnings - totalEarningsBeforeSorting) / totalEarningsBeforeSorting) * 100).toFixed(0)
        : "0"
    const effectiveRate = currentWeight > 0 ? (totalEarnings / currentWeight).toFixed(0) : "0"
    const profitDifference = totalEarnings > totalEarningsBeforeSorting ? totalEarnings - totalEarningsBeforeSorting : 0

    return {
      profitIncrease,
      effectiveRate,
      profitDifference,
    }
  }, [currentWeight, totalEarnings, totalEarningsBeforeSorting])

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="loading-spinner"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-emerald-700 mb-6">Dashboard Pemilahan Sampah</h1>
      </div>

      {/* Summary Cards - Updated with new prices */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <span className="text-2xl mr-2">📊</span>
          Ringkasan Hari Ini
          <div className="ml-2 flex items-center">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping mr-1"></div>
            <span className="text-xs text-emerald-600">Live</span>
          </div>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg hover:shadow-md transition-shadow duration-300">
            <p className="text-gray-600 text-sm mb-2">Total Sampah (kg)</p>
            <h2 className="text-3xl font-bold text-emerald-600">{currentWeight.toFixed(1)} kg</h2>
            <p className="text-xs text-gray-500 mt-1">
              Rata-rata: {dailyAverage > 0 ? dailyAverage.toFixed(1) : "0.0"} kg
            </p>
          </div>
          <div className="text-center p-4 bg-gradient-to-br from-red-50 to-red-100 rounded-lg hover:shadow-md transition-shadow duration-300">
            <p className="text-gray-600 text-sm mb-2">Keuntungan Sebelum Pilah</p>
            <h2 className="text-3xl font-bold text-red-500">Rp {totalEarningsBeforeSorting.toLocaleString("id-ID")}</h2>
            <p className="text-xs text-gray-500 mt-1">Rp {priceBeforeSorting.toLocaleString("id-ID")}/kg</p>
          </div>
          <div className="text-center p-4 bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-lg hover:shadow-md transition-shadow duration-300">
            <p className="text-gray-600 text-sm mb-2">Keuntungan Setelah Pilah</p>
            <h2 className="text-3xl font-bold text-emerald-600">Rp {totalEarnings.toLocaleString("id-ID")}</h2>
            <p className="text-xs text-gray-500 mt-1">Rp {priceAfterSorting.toLocaleString("id-ID")}/kg</p>
          </div>
        </div>

        {/* Progress Info - Updated */}
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Selisih keuntungan per kg:</span>
            <span className="font-semibold text-emerald-600">
              +Rp {(priceAfterSorting - priceBeforeSorting).toLocaleString("id-ID")} (
              {(((priceAfterSorting - priceBeforeSorting) / priceBeforeSorting) * 100).toFixed(1)}%)
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div
              className="bg-emerald-600 h-2 rounded-full transition-all duration-500"
              style={{
                width: `${Math.min(100, (priceAfterSorting / (priceBeforeSorting + priceAfterSorting)) * 100)}%`,
              }}
            ></div>
          </div>
        </div>
      </div>

      {/* Charts - Updated */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <span className="text-2xl mr-2">📈</span>
            Berat Sampah Bulanan
          </h3>
          <div className="h-80">
            <Line data={chartData.weight} options={chartOptions} />
          </div>
          <div className="mt-3 text-xs text-gray-500 text-center">Data historis bulanan (kg)</div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
            <span className="text-2xl mr-2">💰</span>
            Perbandingan Keuntungan
          </h3>
          <div className="h-80">
            <Bar data={chartData.profit} options={chartOptions} />
          </div>
          <div className="mt-3 text-xs text-gray-500 text-center">Sebelum: Rp 8.000/kg vs Sesudah: Rp 13.000/kg</div>
        </div>
      </div>

      {/* Real-time Statistics - Updated */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <span className="text-2xl mr-2">⚡</span>
          Statistik Real-time
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
            <div className="text-2xl mb-2">🎯</div>
            <div className="text-xl font-bold text-purple-600">{calculations.profitIncrease}%</div>
            <div className="text-xs text-gray-600">Peningkatan Profit</div>
          </div>
          <div className="text-center p-4 bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-lg">
            <div className="text-2xl mb-2">⚖️</div>
            <div className="text-xl font-bold text-indigo-600">{currentWeight.toFixed(1)} kg</div>
            <div className="text-xs text-gray-600">Total Berat</div>
          </div>
          <div className="text-center p-4 bg-gradient-to-br from-teal-50 to-teal-100 rounded-lg">
            <div className="text-2xl mb-2">💎</div>
            <div className="text-xl font-bold text-teal-600">
              Rp {calculations.profitDifference.toLocaleString("id-ID")}
            </div>
            <div className="text-xs text-gray-600">Selisih Keuntungan</div>
          </div>
          <div className="text-center p-4 bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg">
            <div className="text-2xl mb-2">📊</div>
            <div className="text-xl font-bold text-amber-600">{calculations.effectiveRate}</div>
            <div className="text-xs text-gray-600">Rp per kg Efektif</div>
          </div>
        </div>
      </div>

      {/* System Status - Updated */}
      <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl p-6 animate-slide-up">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-2">Status Sistem Load Cell</h3>
            <p className="text-emerald-100">Monitoring aktif • Update setiap 5 detik • Data tersinkronisasi</p>
          </div>
          <div className="text-right">
            <div className="flex items-center justify-end mb-2">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse mr-2"></div>
              <span className="font-semibold">Online</span>
            </div>
            <div className="text-sm text-emerald-200">
              Harga: Rp {priceAfterSorting.toLocaleString("id-ID")}/kg (setelah pilah)
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
