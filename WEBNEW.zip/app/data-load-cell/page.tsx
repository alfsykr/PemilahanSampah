"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js"
import { loadCellStore } from "@/lib/loadCellStore"
// import FirebaseToggle from "@/components/FirebaseToggle" // Hapus import ini

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend)

export default function DataLoadCell() {
  const [isLoaded, setIsLoaded] = useState(false)
  const [totalAccumulatedWeightKg, setTotalAccumulatedWeightKg] = useState(0) // Total dari historyBerat (dalam kg)
  const [realtimeCurrentWeightGrams, setRealtimeCurrentWeightGrams] = useState(0) // Berat realtime dari realtimeBerat
  const [dailyAverage, setDailyAverage] = useState(0)
  const [totalEarnings, setTotalEarnings] = useState(0)
  const [completedCycles, setCompletedCycles] = useState(0)
  const [isConnected, setIsConnected] = useState(false) // Ganti useFirebase dengan isConnected
  const [priceAfterSorting, setPriceAfterSorting] = useState(0)
  const [debugInfo, setDebugInfo] = useState<any>(null) // Tambahkan debug info

  // Optimized update handler
  const updateData = useCallback(() => {
    setTotalAccumulatedWeightKg(loadCellStore.getTotalAccumulatedWeightInKg()) // Total dari historyBerat (dalam kg)
    setRealtimeCurrentWeightGrams(loadCellStore.getRealtimeWeightInGrams()) // Realtime dari realtimeBerat
    setDailyAverage(loadCellStore.getDailyAverage())
    setTotalEarnings(loadCellStore.getTotalEarnings())
    setCompletedCycles(loadCellStore.getCompletedCycles())
    setIsConnected(loadCellStore.isFirebaseConnected()) // Ambil status koneksi
    setPriceAfterSorting(loadCellStore.getPriceAfterSorting())
    setDebugInfo(loadCellStore.getFirebaseDebugInfo()) // Ambil debug info
  }, [])

  useEffect(() => {
    setIsLoaded(true)

    const unsubscribe = loadCellStore.subscribe(updateData)
    updateData()

    return unsubscribe
  }, [updateData])

  // Memoized calculations
  const calculations = useMemo(() => {
    const remainingWeight = totalAccumulatedWeightKg - completedCycles

    return {
      remainingWeight,
      progressPercentage: (totalAccumulatedWeightKg % 1) * 100, // Progress per kg
    }
  }, [totalAccumulatedWeightKg, completedCycles])

  if (!isLoaded) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="loading-spinner"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-emerald-700 mb-6">Data Load Cell</h1>
      </div>

      {/* Firebase Toggle - Hapus komponen ini */}
      {/* <FirebaseToggle /> */}

      {/* Status Koneksi Firebase (pengganti FirebaseToggle) */}
      <div className="bg-white rounded-xl shadow-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div
              className={`w-3 h-3 rounded-full ${isConnected ? "bg-green-500" : "bg-red-500"} ${!isConnected ? "animate-pulse" : ""}`}
            ></div>
            <div>
              <h3 className="font-semibold text-gray-800">Sumber Data</h3>
              <p className="text-sm text-gray-600">{isConnected ? "Firebase Terhubung" : "Firebase Terputus"}</p>
            </div>
          </div>
          {/* Tombol Putuskan/Hubungkan Firebase dihapus */}
        </div>

        {/* Connection Info */}
        <div className="mt-3 p-3 bg-gray-50 rounded-lg">
          <div className="text-xs text-gray-600 space-y-1">
            <div className="flex justify-between">
              <span>Mode:</span>
              <span className="font-medium">Firebase Real-time</span>
            </div>
            <div className="flex justify-between">
              <span>Status:</span>
              <span className={`font-medium ${isConnected ? "text-green-600" : "text-gray-600"}`}>
                {isConnected ? "Online" : "Offline"}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Increment:</span>
              <span className="font-medium">Per 20 gr</span>
            </div>
          </div>
        </div>

        {/* Firebase Info */}
        <div className="mt-2 p-2 bg-blue-50 rounded-lg">
          <p className="text-xs text-blue-700">
            📡 Mengambil data dari: <code className="bg-blue-100 px-1 rounded">historyBerat</code> (total) &{" "}
            <code className="bg-blue-100 px-1 rounded">realtimeBerat/berat</code> (realtime)
          </p>
          <p className="text-xs text-blue-600 mt-1">Data dikirim bertahap per 20 gr setiap 2 detik</p>
        </div>

        {/* Debug Info */}
        {debugInfo && (
          <div className="mt-2 p-2 bg-yellow-50 rounded-lg">
            <p className="text-xs text-yellow-700 font-semibold mb-1">Debug Info:</p>
            <div className="text-xs text-yellow-600 space-y-1">
              <div className="flex justify-between">
                <span>Raw Total Weight (history):</span>
                <span>{debugInfo.rawTotalWeight}gr</span>
              </div>
              <div className="flex justify-between">
                <span>Processed Total Weight (history):</span>
                <span>{debugInfo.processedTotalWeight}gr</span>
              </div>
              <div className="flex justify-between">
                <span>Realtime Weight:</span>
                <span>{debugInfo.realtimeWeight}gr</span>
              </div>
              <div className="flex justify-between">
                <span>Next Target (history):</span>
                <span>{debugInfo.nextTarget}gr</span>
              </div>
              <div className="flex justify-between">
                <span>Processing (history):</span>
                <span className={debugInfo.isProcessing ? "text-green-600" : "text-gray-600"}>
                  {debugInfo.isProcessing ? "Yes" : "No"}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Current Weight Display - Ubah ke gr saja dengan font lebih besar */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Berat Saat Ini</h2>
          <div className="text-8xl font-bold text-emerald-600 mb-4 animate-pulse">
            {realtimeCurrentWeightGrams.toLocaleString()} gr
          </div>
          <div className="flex justify-center items-center space-x-2 mb-4">
            <div
              className={`w-3 h-3 rounded-full animate-ping bg-blue-500`} // Selalu biru
            ></div>
            <span className={`font-medium text-blue-600`}>Firebase Live</span> {/* Selalu Firebase Live */}
          </div>

          {/* Progress info */}
          <div className="max-w-md mx-auto">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Keuntungan per kg:</span>
              <span className="font-semibold text-emerald-600">Rp {priceAfterSorting.toLocaleString("id-ID")}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className={`h-3 rounded-full transition-all duration-500 bg-blue-600`} // Selalu biru
                style={{ width: `${calculations.progressPercentage}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Earnings Display - Enhanced */}
      <div
        className={`bg-gradient-to-br text-white rounded-xl p-6 animate-slide-up from-blue-500 to-blue-600`} // Selalu biru
      >
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-3xl mb-2">💰</div>
            <div className="text-2xl font-bold">Rp {totalEarnings.toLocaleString("id-ID")}</div>
            <div className={"text-blue-100"}>Total Keuntungan</div> {/* Selalu biru */}
            <div className="text-xs mt-1 opacity-80">Rp {priceAfterSorting.toLocaleString("id-ID")}/kg</div>
          </div>
          <div>
            <div className="text-3xl mb-2">📊</div>
            <div className="text-2xl font-bold">{completedCycles.toFixed(1)} kg</div>
            <div className={"text-blue-100"}>Berat Terhitung</div> {/* Selalu biru */}
          </div>
          <div>
            <div className="text-3xl mb-2">⚖️</div>
            <div className="text-2xl font-bold">{calculations.remainingWeight.toFixed(1)} kg</div>
            <div className={"text-blue-100"}>Sisa Berat</div> {/* Selalu biru */}
          </div>
        </div>
      </div>

      {/* Statistics Cards - Enhanced */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl p-6 animate-slide-up">
          <div className="text-3xl mb-2">📊</div>
          <div className="text-2xl font-bold">{dailyAverage.toFixed(1)} kg</div>
          <div className="text-blue-100">Rata-rata Harian</div>
          <div className="text-xs text-blue-200 mt-1">
            {dailyAverage > 0 ? "Berdasarkan data terkumpul" : "Belum ada data"}
          </div>
        </div>
        <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-xl p-6 animate-slide-up">
          <div className="text-3xl mb-2">💵</div>
          <div className="text-2xl font-bold">Rp {priceAfterSorting.toLocaleString("id-ID")}</div>
          <div className="text-orange-100">Harga per Kg</div>
          <div className="text-xs text-orange-200 mt-1">Setelah pilah</div>
        </div>
      </div>

      {/* Calculation Details - Enhanced with new prices */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <span className="text-2xl mr-2">🧮</span>
          Detail Perhitungan
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Sistem Perhitungan:</span>
              <span className="font-semibold">Per gr</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
              <span className="text-gray-600">Harga Sebelum Pilah:</span>
              <span className="font-semibold text-red-600">Rp 8.000/kg</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-lg">
              <span className="text-gray-600">Harga Setelah Pilah:</span>
              <span className="font-semibold text-emerald-600">Rp 13.000/kg</span>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-lg">
              <span className="text-gray-600">Berat Terkumpul:</span>
              <span className="font-semibold">
                {loadCellStore.getTotalAccumulatedWeightInGrams().toLocaleString()} gr
              </span>
            </div>
            {/* Selisih Keuntungan dihapus */}
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-lg">
              <span className="text-gray-600">Total Keuntungan:</span>
              <span className="font-semibold text-emerald-600">Rp {totalEarnings.toLocaleString("id-ID")}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Control Buttons - Enhanced */}
      <div className="bg-white rounded-xl shadow-lg p-6 animate-slide-up">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Kontrol Sistem</h3>
        <div className="flex gap-4 flex-wrap">
          <button
            onClick={() => loadCellStore.reset()}
            className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors duration-200"
          >
            Reset Data
          </button>
          <div className="flex items-center text-sm text-gray-600">
            <div
              className={`w-2 h-2 rounded-full animate-pulse mr-2 bg-blue-500`} // Selalu biru
            ></div>
            Data real-time dari Firebase
          </div>
        </div>
      </div>
    </div>
  )
}
